package com.vlprojects.divergence

import android.appwidget.AppWidgetManager
import android.content.Context
import android.widget.RemoteViews
import kotlin.random.Random

class DivergenceWidget : android.appwidget.AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // There may be multiple widgets active, so update all of them
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    // override fun onEnabled(context: Context) {}

    companion object {

        internal fun updateAppWidget(
            context: Context, appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val widgetText = "${Random.nextInt(12000000).toDouble()/10000000}, id: $appWidgetId"
            // Construct the RemoteViews object
            val views = RemoteViews(context.packageName, R.layout.divergence_widget)
            views.setTextViewText(R.id.appwidget_text, widgetText)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}